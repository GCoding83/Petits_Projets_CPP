#include "Sac de Ciment.h"

Sac de Ciment::Sac de Ciment()
{
    //ctor
}

Sac de Ciment::~Sac de Ciment()
{
    //dtor
}
