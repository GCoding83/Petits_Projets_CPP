#include "Facture.h"

Facture::Facture()
{
    //ctor
}

Facture::~Facture()
{
    //dtor
}
