#ifndef SAC DE CIMENT_H
#define SAC DE CIMENT_H


class Sac de Ciment
{
    public:
        Sac de Ciment();
        virtual ~Sac de Ciment();

    protected:

    private:
};

#endif // SAC DE CIMENT_H
