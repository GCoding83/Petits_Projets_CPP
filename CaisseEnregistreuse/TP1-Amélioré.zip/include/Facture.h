#ifndef FACTURE_H
#define FACTURE_H


class Facture
{
    public:
        Facture();
        virtual ~Facture();

    protected:

    private:
};

#endif // FACTURE_H
